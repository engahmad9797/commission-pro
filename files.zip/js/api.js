// دوال جلب البيانات من واجهات البرمجة الخارجية أو الداخلية

async function fetchProducts() {
  // TODO: أضف منطق جلب المنتجات من API هنا
}

async function fetchCampaigns() {
  // TODO: أضف منطق جلب الحملات من API هنا
}

// يمكنك تصدير الدوال إذا كنت تستخدم ES6 Modules
// export { fetchProducts, fetchCampaigns };