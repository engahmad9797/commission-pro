// دوال التعامل مع قاعدة البيانات (إضافة، استرجاع، تحديث)

function addData(collection, data) {
  // TODO: أضف منطق إضافة البيانات هنا
}

function getData(collection) {
  // TODO: أضف منطق جلب البيانات هنا
}

// يمكنك تصدير الدوال إذا كنت تستخدم ES6 Modules
// export { addData, getData };