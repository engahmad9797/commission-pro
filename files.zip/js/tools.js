// دوال الأدوات الإضافية (توليد روابط، QR ...)

function generateShortLink(url) {
  // TODO: أضف منطق توليد رابط مختصر هنا
}

function generateQRCode(data) {
  // TODO: أضف منطق توليد QR code هنا
}

// يمكنك تصدير الدوال إذا كنت تستخدم ES6 Modules
// export { generateShortLink, generateQRCode };